#include <iostream>
#include <vector>
#include <cmath>
#include <iomanip>

using namespace std;

int main() {
    int n, m;

    cout << "========================================================\n";
    cout << "  UNIVERSAL POLYFIT ENGINE (ANY DEGREE POLYNOMIAL)      \n";
    cout << "========================================================\n\n";

    // 1. READ INPUTS
    cout << "Enter number of data points (N): ";
    cin >> n;

    cout << "Enter polynomial degree (m, where m < N): ";
    cin >> m;

    if (m >= n) {
        cout << "Error: Degree (m) must be strictly less than number of points (N).\n";
        return 1;
    }

    vector<double> x(n), y(n);
    cout << "\nEnter " << n << " data points (x y):\n";
    for (int i = 0; i < n; i++) {
        cout << "Point " << i + 1 << ": ";
        cin >> x[i] >> y[i];
    }

    // 2. BUILD NORMAL EQUATIONS MATRIX
    int size = m + 1; // Size of linear system matrix
    vector<vector<double>> A(size, vector<double>(size + 1, 0.0)); // Augmented matrix [A|B]

    // Fill matrix A with sums of x powers: sum(x^(i+j))
    for (int i = 0; i < size; i++) {
        for (int j = 0; j < size; j++) {
            for (int k = 0; k < n; k++) {
                A[i][j] += pow(x[k], i + j);
            }
        }
    }

    // Fill rightmost column B with sum(y * x^i)
    for (int i = 0; i < size; i++) {
        for (int k = 0; k < n; k++) {
            A[i][size] += y[k] * pow(x[k], i);
        }
    }

    // 3. GAUSSIAN ELIMINATION (SOLVE FOR COEFFICIENTS)
    for (int i = 0; i < size; i++) {
        // Find pivot row
        int maxRow = i;
        for (int k = i + 1; k < size; k++) {
            if (abs(A[k][i]) > abs(A[maxRow][i])) maxRow = k;
        }
        swap(A[i], A[maxRow]);

        // Eliminate entries below pivot
        for (int k = i + 1; k < size; k++) {
            double factor = A[k][i] / A[i][i];
            for (int j = i; j <= size; j++) {
                A[k][j] -= factor * A[i][j];
            }
        }
    }

    // Back-Substitution to extract coefficients a_0, a_1, ..., a_m
    vector<double> a(size);
    for (int i = size - 1; i >= 0; i--) {
        a[i] = A[i][size];
        for (int j = i + 1; j < size; j++) {
            a[i] -= A[i][j] * a[j];
        }
        a[i] /= A[i][i];
    }

    // 4. DISPLAY RESULTING POLYNOMIAL
    cout << "\n========================================================\n";
    cout << "              FITTED POLYNOMIAL MODEL                  \n";
    cout << "========================================================\n";
    cout << fixed << setprecision(4);
    cout << "y = " << a[0];
    for (int i = 1; i <= m; i++) {
        cout << " + (" << a[i] << ")x^" << i;
    }
    cout << "\n--------------------------------------------------------\n";

    // 5. ACCURACY EVALUATION (R-Squared)
    double sumY = 0;
    for (int i = 0; i < n; i++) sumY += y[i];
    double meanY = sumY / n;

    double ssTot = 0, ssRes = 0;
    for (int i = 0; i < n; i++) {
        double yPred = 0;
        for (int j = 0; j <= m; j++) {
            yPred += a[j] * pow(x[i], j);
        }
        ssTot += pow(y[i] - meanY, 2);
        ssRes += pow(y[i] - yPred, 2);
    }

    double r2 = 1.0 - (ssRes / ssTot);
    cout << "R-Squared Score (Goodness of Fit): " << r2 << "\n";
    cout << "========================================================\n";

    // 6. PREDICTION INTERFACE
    double xPredict;
    cout << "\nEnter an x value to predict y: ";
    cin >> xPredict;

    double yPredicted = 0;
    for (int i = 0; i <= m; i++) {
        yPredicted += a[i] * pow(xPredict, i);
    }

    cout << "Predicted y at x = " << xPredict << " is: " << yPredicted << "\n";
    cout << "========================================================\n";

    return 0;
}